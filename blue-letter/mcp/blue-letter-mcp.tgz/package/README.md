# Blue Letter MCP（リリックMV）

Claude や Codex に曲と歌詞を渡して「リリックMVを作って」と頼むと、Blue Letter が曲の盛り上がりと歌詞の気持ちに合わせて演出を組み、MP4 をこのパソコンに保存します。無料です。

## 入れ方（最初に一度だけ）

**Claude デスクトップアプリ（Mac / Windows）**
`blue-letter.mcpb` をダブルクリックして「インストール」を押します（開かないときは、Claude の 設定 → 拡張機能 にドラッグします）。

**Codex**（ターミナルで1行）

```
codex mcp add blue-letter -- npx -y -p https://blueletterjp.github.io/blue-letter/mcp/blue-letter-mcp.tgz blue-letter-mcp
```

**Claude Code**（ターミナルで1行）

```
claude mcp add blue-letter -- npx -y -p https://blueletterjp.github.io/blue-letter/mcp/blue-letter-mcp.tgz blue-letter-mcp
```

Windows では `npx` の前に `cmd /c ` を付けます。Google Chrome か Microsoft Edge が入っていれば動きます（Codex と Claude Code では Node.js 18 以上も使います）。

## 使い方（頼み方の例）

- 「Blue Letter で、ダウンロードにある `song.mp3` と下の歌詞でリリックMVを作って。サビは高揚感を強めに」
- 「2番の案で。縦長（ショート）にして、夜っぽく」
- 「2行目は 0:35 から、サビは 1:02 から」
- 「1080p で書き出して」

曲はファイル名で伝えれば、作業フォルダ・ダウンロード・ミュージック・デスクトップ・書類などから探します。AI は曲を分析して（テンポ・Aメロ／サビなどの構成・盛り上がり）、行ごとに感情・勢い・モチーフを決めて演出し、確認用の絵を見せます。雰囲気・配色・縦横・「文字だけ」・「ボカロMV風」・「3Dリリック」も変えられます。

## 大事なこと

- **Blue Letter はこのパソコンの中だけで動きます。** 見えない Chrome / Edge の中で Blue Letter のページが動き、曲はどこにも送りません（AI に届くのは、曲の分析と確認用の画像だけです。書体は Google Fonts から読み込みます）。
- 書き出した MP4 と作品ファイル（`.blueletter.json`）は「ムービー」（Windows は「ビデオ」）の `Blue Letter` フォルダに入ります。Claude デスクトップでは拡張の設定で変えられます（Codex / Claude Code では環境変数 `BLUE_LETTER_OUT`）。
- 自分で直したいときは、https://blueletterjp.github.io/blue-letter/ の「開く」で作品ファイルを読み込み、同じ曲をドロップしてください。AI が演出した行には「AI：…」と出て、そのまま手で直せます。
- AI は曲を聞けないので、歌い出しのタイミングは拍に合わせた自動の割り振りです。時間を伝えるか、時間付きの歌詞（LRC）を渡すと正確になります。
- キャラの画像（ボカロMV風）は、サイトの画面から入れてください。

---

## English

Give Claude or Codex a song file and its lyrics and ask for a lyric video: Blue Letter directs it to the song's structure and the feeling of the words and saves an MP4 — entirely on this computer, free; the song is never uploaded.

- **Claude Desktop:** double-click `blue-letter.mcpb` and press Install.
- **Codex:** `codex mcp add blue-letter -- npx -y -p https://blueletterjp.github.io/blue-letter/mcp/blue-letter-mcp.tgz blue-letter-mcp`
- **Claude Code:** `claude mcp add blue-letter -- npx -y -p https://blueletterjp.github.io/blue-letter/mcp/blue-letter-mcp.tgz blue-letter-mcp`
- On Windows put `cmd /c ` before `npx`. Needs Google Chrome or Microsoft Edge (and Node.js 18+ for Codex / Claude Code).

Ask e.g. “With Blue Letter, make a lyric video from song.mp3 in Downloads and these lyrics”. The video and the project file go to Movies (Videos on Windows) → `Blue Letter`; open the project file on the site to change anything by hand.

© 2026 Blue Letter. All rights reserved. Parts of Blue Letter come from JIZURA (MIT License) — see THIRD_PARTY_NOTICES.txt.
